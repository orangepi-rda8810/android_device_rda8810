#ifndef __TGT_AP_TS_SETTING_H
#define __TGT_AP_TS_SETTING_H

#include "rda_ts_comm.h"

/* #define TGT_AP_TS_FW_RELOAD		(1) */

#endif
